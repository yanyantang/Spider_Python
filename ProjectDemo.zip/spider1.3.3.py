# 百度/360搜索关键词提交，查明接口，params参数的使用
#author：唐燕艳
#date：20180531

import requests
keyword = "Python"
try:
    # for baidu 
    #kv = {"wd":keyword}
    # for 360
    kv = {"q":keyword}
    r = requests.get("http://www.so.com/s",params = kv)
    r.raise_for_status()
    print(r.request.url)
    r.encoding = r.apparent_encoding
    print(len(r.text))
except:
    print("爬取失败")

