# 京东商品页面的常规爬取
#author： 唐燕艳
#date：20180531

import requests
url = "https://item.jd.com/6008133.html"
try:
    r = requests.get(url)
    r.raise_for_status()
    r.encoding = r.apparent_encoding
    print(r.text[:1000])
except:
    print("爬取失败")
