#亚马逊商品页面的爬取，503错误，设置user_agent
#author：唐燕艳
#date：20180531

import requests
url = "https://www.amazon.cn/dp/B0785D5L1H"
try:
    kv = {"user-agent":"Mozilla/5.0"}
    r = requests.get(url,headers = kv)
    r.raise_for_status()
    r.encoding = r.apparent_encoding
    print(r.request.headers)
    print(r.text[1000:2000])
except:
    print("爬取失败")
